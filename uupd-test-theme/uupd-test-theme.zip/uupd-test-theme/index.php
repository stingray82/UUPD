<?php
// Basic index.php to satisfy WordPress theme requirements
get_header();
echo '<main><h1>Hello from UUPD Test Theme!</h1></main>';
get_footer();
